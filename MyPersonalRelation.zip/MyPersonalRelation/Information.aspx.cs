﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyPersonalRelation
{
    public partial class Information : System.Web.UI.Page
    {
        #region 被调用的代码
        private static string connStr = ConfigurationManager.ConnectionStrings["Relation"].ToString();
        private SqlConnection con = new SqlConnection(connStr);
        public int PageSize = 10; //一页显示多少条数据
        private int _PageIndex; //页码
        public int PageIndex
        {
            get
            {
                try
                {
                    _PageIndex = Request.QueryString["page"] == null ? 1 : Convert.ToInt32(Request.QueryString["page"].ToString());
                }
                catch (Exception)
                {
                    //默认第一页
                    _PageIndex = 1;
                }
                return _PageIndex;
            }
            set { _PageIndex = value; }
        }

        //获取总记录数
        public int UserCount()
        {
            OpenDB();
            string sSql = "select count(*) from RelationShip";
            using (SqlCommand cmd = new SqlCommand(sSql, con))
            {
                return Convert.ToInt32(cmd.ExecuteScalar().ToString());
            }
        }

        //总页数
        public int PageCount()
        {
            //% 是整除 mod
            if (UserCount() % PageSize == 0)
            {
                return UserCount() / PageSize;
            }
            else
            {
                //怎么解决下面的问题呢?
                //return Math.Ceiling(Convert.ToDouble(UserCount()/PageSize));
                double dTemp = Convert.ToDouble(UserCount()) / Convert.ToDouble(PageSize);
                return Convert.ToInt32(Math.Ceiling(dTemp));//最终结果要变成 int 
            }
        }

        //分页控件
        public string GetPager()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(@"<div><a href=""/Information.aspx?page=1"">第一页</a></div>");

            //已经是第一页了
            if (PageIndex == 1)
            {
                sb.Append(@"<div><a href=""javascript:;"">上一页</a></div>");
            }
            else
            {
                sb.Append(string.Format(@"<div><a href=""/Information.aspx?page={0}"">上一页</a></div>", PageIndex - 1));
            }

            //已经是最后一页了
            if (PageIndex == PageCount())
            {
                sb.Append(@"<div><a href=""javascript:;"">下一页</a></div>");
            }
            else
            {
                sb.Append(string.Format(@"<div><a href=""/Information.aspx?page={0}"">下一页</a></div>", PageIndex + 1));
            }

            //尾页
            sb.Append(string.Format(@"<div><a href=""/Information.aspx?page={0}"">最后一页</a></div>", PageCount()));

            //页码
            sb.Append(string.Format("<div>{0}/{1}</div>", PageIndex, PageCount()));

            return sb.ToString();
        }

        /// <summary>
        /// 打开数据库
        /// </summary>
        public void OpenDB()
        {
            try
            {
                con = new SqlConnection(connStr);
                con.Open();
            }
            catch (Exception)
            {
                Response.Write(@"<script>alert(""未知错误!"");</script>");
            }
        }

        /// <summary>
        /// 绑定数据库
        /// </summary>
        public void BindUser()
        {
            OpenDB();
            try
            {
                string sSql = getSql();
                using (SqlCommand com = new SqlCommand(sSql, con))
                {
                    using (SqlDataReader reader = com.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            GridViewRelation.DataSource = reader;//get the data
                            GridViewRelation.DataBind();//bind the data
                        }
                    }
                }
            }
            catch (Exception)
            {
                Response.Write(@"<script>alert(""未知错误!"");</script>");
            }
        }

        /// <summary>
        /// 获取数据库查询字段
        /// </summary>
        /// <returns></returns>
        public string getSql()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(string.Format(@"select top {0} * from 
                (select row_number() over(order by RelationId) as rownumber,RelationId,Name,Region,WorkPlace,PhoneNumber,Introduction,Class,gender from RelationShip where 1=1", PageSize));
            if (!string.IsNullOrEmpty(TextBoxRelationId.Text.Trim()))
            {
                sb.Append(string.Format(" and RelationId={0}", TextBoxRelationId.Text.Trim()));
            }
            if (!string.IsNullOrEmpty(TextBoxUserName.Text.Trim()))
            {
                sb.Append(string.Format(" and UserName={0}", TextBoxUserName.Text.Trim()));
            }
            if (DropDownListGender.SelectedIndex > 0)
            {
                sb.Append(string.Format("and gender= '{0}'", DropDownListGender.SelectedValue));
            }
            sb.Append(string.Format(@")A Where rownumber > {0}", (PageIndex - 1) * PageSize));
            return sb.ToString();
        }
        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)//只调用下面这个方法一次
            {
                BindUser();
            }
            GridViewRelation.DataKeyNames = new string[] { "RelationId" };//绑定主键
            //如果没有密码就到主页
            if (Session["username"] == null || Session["pwd"] == null)
            {
                Response.Redirect("index.aspx");
            }
        }

        /// <summary>
        /// 查找
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ButtonSearch_Click(object sender, EventArgs e)
        {
            BindUser();
        }

        /// <summary>
        /// 编辑--第一步
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GridViewRelation_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridViewRelation.EditIndex = e.NewEditIndex;
            BindUser();
        }

        /// <summary>
        /// 取消--配合编辑使用(第二部)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GridViewRelation_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridViewRelation.EditIndex = -1;//The default is -1, which indicates that no row is being edited.
            BindUser();
        }

        /// <summary>
        /// 更新--配合编辑使用(第三部)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GridViewRelation_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            OpenDB();
            try
            {
                string sSqlUpdate = string.Format(@"update RelationShip set Name='{0}',Region='{1}',
                    WorkPlace='{2}',PhoneNumber='{3}',Introduction='{4}',Class='{5}',gender='{6}' where RelationId={7}",
                            ((TextBox)(GridViewRelation.Rows[e.RowIndex].Cells[1].Controls[0])).Text.Trim().ToString(),
                            ((TextBox)(GridViewRelation.Rows[e.RowIndex].Cells[2].Controls[0])).Text.Trim().ToString(),
                            ((TextBox)(GridViewRelation.Rows[e.RowIndex].Cells[3].Controls[0])).Text.Trim().ToString(),
                            ((TextBox)(GridViewRelation.Rows[e.RowIndex].Cells[4].Controls[0])).Text.Trim().ToString(),
                            ((TextBox)(GridViewRelation.Rows[e.RowIndex].Cells[5].Controls[0])).Text.Trim().ToString(),
                            ((TextBox)(GridViewRelation.Rows[e.RowIndex].Cells[6].Controls[0])).Text.Trim().ToString(),
                            ((TextBox)(GridViewRelation.Rows[e.RowIndex].Cells[7].Controls[0])).Text.Trim().ToString(),
                            Convert.ToInt32(((TextBox)(GridViewRelation.Rows[e.RowIndex].Cells[0].Controls[0])).Text.Trim().ToString())
                            );
                using (SqlCommand cmd = new SqlCommand(sSqlUpdate, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                Response.Write(@"<script>alert(""未知错误!"");</script>");
            }
            GridViewRelation.EditIndex = -1;//The default is -1, which indicates that no row is being edited.
            BindUser();
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GridViewRelation_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            OpenDB();
            try
            {
                string sSqlDel = string.Format(@"delete RelationShip where RelationId= {0}",
                        Convert.ToInt32(GridViewRelation.DataKeys[e.RowIndex].Value.ToString()));
                using (SqlCommand cmd = new SqlCommand(sSqlDel, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                Response.Write(@"<script>alert(""未知错误!"");</script>");
            }
            GridViewRelation.EditIndex = -1;//The default is -1, which indicates that no row is being edited.
            BindUser();
        }
    }
}