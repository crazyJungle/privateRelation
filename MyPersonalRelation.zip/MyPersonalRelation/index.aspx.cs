﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace MyPersonalRelation
{
    public partial class index : System.Web.UI.Page
    {
        #region 被调用的代码
        private static string connStr = ConfigurationManager.ConnectionStrings["Relation"].ToString();
        private SqlConnection con = new SqlConnection(connStr);

        /// <summary>
        /// 打开数据库
        /// </summary>
        public void OpenDB()
        {
            try
            {
                con = new SqlConnection(connStr);
                con.Open();
            }
            catch (Exception)
            {
                Response.Write(@"<script>alert(""未知错误!"");</script>");
            }
        }
        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            CheckBox_Rememberme.Checked = true;//默认选中
        }

        private string sUserName;
        private string sPassWord;
        HttpCookie UsernameCookie = new HttpCookie("UsernameCookie");
        HttpCookie PasswordCookie = new HttpCookie("PasswordCookie");

        /// <summary>
        /// 登录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button_Login_Click(object sender, EventArgs e)
        {
            try
            {
                sUserName = TextBox_Username.Text.Trim();
                sPassWord = TextBox_Password.Text.Trim();
                //防止无密码就进入界面
                Session.Add("username", sUserName);
                Session.Add("pwd", sPassWord);
                if (string.IsNullOrEmpty(sUserName) || string.IsNullOrEmpty(sPassWord)) 
                {
                    Response.Write(@"<script>alert(""用户名或密码为空!"");</script>");
                }
                else 
                {
                    //实现记住用户名和密码的功能---尚未实现
                    if (CheckBox_Rememberme.Checked == true)
                    {
                        if (UsernameCookie.Value == null)
                        {
                            //下面两种方法都没有实现保存密码并在下次登录时自动填写密码.
                            //法一 http://www.jb51.net/article/59448.htm
                            UsernameCookie.Expires = DateTime.Now.AddDays(30);
                            UsernameCookie.Value = sUserName;
                            HttpContext.Current.Response.Cookies.Add(UsernameCookie);
                            PasswordCookie.Expires = DateTime.Now.AddDays(30);
                            PasswordCookie.Value = sPassWord;
                            HttpContext.Current.Response.Cookies.Add(PasswordCookie);

                            //法二 http://www.cnblogs.com/wxylog/p/6110176.html
                            //Response.Cookies["sUsernameCookie"].Expires = DateTime.Now.AddDays(30);
                            //Response.Cookies["sUsernameCookie"].Value = sUserName;
                            //Response.Cookies["sPasswordCookie"].Expires = DateTime.Now.AddDays(30);
                            //Response.Cookies["sPasswordCookie"].Value = sPassWord;
                        }
                    }
                    OpenDB();
                    string sSqlIsHave = string.Format("select AccessId from AccessIn where UserName='{0}' and Password='{1}'",sUserName,sPassWord);
                    using(SqlCommand cmd = new SqlCommand(sSqlIsHave,con))
                    {
                        using(SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                Response.Redirect("Information.aspx");
                            }
                            else
                            {
                                Response.Write(@"<script>alert(""用户名或密码错误,请重试!"");</script>");
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                Response.Write(@"<script>alert(""未知错误!"");</script>");
            }
        }

        /// <summary>
        /// 当用户名改变时自动填充密码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void TextBox_Username_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TextBox_Username.Text.Trim().ToString()))
            {
                if (UsernameCookie.Value != null)
                {
                    if (UsernameCookie.Value.Equals(Session["username"]))
                    {
                        TextBox_Password.Attributes["value"] = PasswordCookie.Value;
                    }
                } 
            }
        }
    }
}